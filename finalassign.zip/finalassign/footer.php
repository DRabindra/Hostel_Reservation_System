<?php
$base_url="http://localhost/finalassign/";
?>


</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="<?php echo $base_url;?>dist/js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo $base_url;?>dist/js/bootstrap.min.js"></script>
<script src="<?php echo $base_url;?>dist/js/bootstrap-datepicker.js"></script>
<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo $base_url;?>dist/js/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript
<script src="<?php echo $base_url;?>dist/js/raphael-min.js"></script>
<script src="<?php echo $base_url;?>dist/js/morris.min.js"></script>
<script src="<?php echo $base_url;?>dist/js/morris-data.js"></script>
-->
<!-- Custom Theme JavaScript -->
<script src="<?php echo $base_url;?>dist/js/sb-admin-2.js"></script>
<script src="<?php echo $base_url;?>dist/js/dataTable.js"></script>
<script src="<?php echo $base_url;?>dist/js/timepicker.js"></script>

<script src="<?php echo $base_url;?>dist/js/modernizr.custom.63321.js"></script>

<script src="<?php echo $base_url;?>dist/js/jquery.calendario.js"></script>
<script src="<?php echo $base_url;?>dist/js/data.js"></script>
<script src="<?php echo $base_url;?>dist/js/app.js"></script>

</body>

</html>
